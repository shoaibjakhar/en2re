@extends('HR.hrlayouts')
@section('content')

<div class=" page-content-wrapper">
    <!-- start input -->
    <div class="page-content hero2">
        <div class="portlet light bordered " id="form_wizard_1">
            <div class="portlet-body form">
                <div class="row">

                    <div class="col-md-12 mx-0">
                        <div>
                            <div class="form-group ">

                                <div class="left">
                                    <div class="wrapper center-block">
                                        <div class="left">
                                            <div class="col-md-12 mb-40 box-bd">
                                                <div class="col-md-12 mb-40 box-bd">
                                                    <div class="portlet-body">
                                                        <h4>Blog/Feed Inbox</h4>
                                                        <div class="col-md-6">
                                                            <label class="control-label left ">Blog Name</label>
                                                            <input type="text" value="" class="form-control" name="" />
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="control-label left ">Blog Header</label>
                                                            <input type="text" value="" class="form-control" name="" />
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="control-label left ">Launch Date</label>
                                                            <input type="date" value="" class="form-control" name="" />
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="control-label left ">Campaign Message	</label>
                                                            <input type="text" value="" class="form-control" name="" />
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="control-label left ">Text Body </label>
                                                            <input type="text" value="" class="form-control" name="" />
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="control-label left ">Pictures </label><br>
                                                            <input type="file" src="" alt="Submit" class="form-control" width="48" height="48">
                                                        </div>
                                                    </div>
                                                    <button type="submit" value="" class="btn btn-primary col-md-2 mt-4" style="margin-left: 40%">Submit</button>
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            <div class="portlet-body form">
                <div class="row">

                    <div class="col-md-12 mx-0">
                        <div>
                            <div class="form-group ">

                                <div class="left">
                                    <div class="wrapper center-block">
                                        <div class="left">
                                            <div class="col-md-12 mb-40 box-bd">

                                                <div class="col-md-8">
                                                    <h4 class="">
                                                        <strong>Blog/Feed View</strong>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="col-md-12 mb-40 box-bd">
                                                <div class="portlet-body filter-none">
                                                    <div id="sample_5_wrapper" class="dataTables_wrapper">
                                                        <div class="table Add">
                                                            <div class="table-scrollable">
                                                                <table class="table table-hover  order-column dataTable" role="grid" aria-describedby="sample_5_info">
                                                                    <thead>
                                                                        <tr class="secondary_bg font-white">
                                                                            <th style="width: 88px;">ID</th>
                                                                            <th style="width: 88px;">
                                                                                Blog Name
                                                                            </th>
                                                                            <th style="width: 88px;"> Blog Header
                                                                            </th>

                                                                            <th style="width: 59px;"> Launch Date
                                                                            </th>
                                                                            <th style="width: 59px;"> Campaign Message
                                                                            </th>
                                                                            <th style="width: 59px;"> Text Body
                                                                            </th>
                                                                            <th style="width: 59px;"> Pictures
                                                                            </th>
                                                                            <th style="width: 59px;">
                                                                                Action
                                                                            </th>


                                                                        </tr>
                                                                    </thead>

                                                                    <tbody>
                                                                        <tr data-toggle="collapse" class="" data-target="#sample_5">

                                                                            <td class="ft-16"><b> 3</b>
                                                                            </td>
                                                                            <td class="ft-16">Zubair</td>
                                                                            <td class="ft-16">Bold</td>
                                                                            <td class="ft-16">12-23-2002
                                                                            </td>
                                                                            <td class="ft-16">
                                                                                Hello Micle</td>
                                                                            <td class="ft-16">175 letters</td>
                                                                            <td class="ft-16"><img src="{{ asset('./assets/img/web.jpg') }}" class="highlight4" height="24" width="24" alt=""></td>
                                                                            <td class="ft-16">
                                                                                <i class="bi bi-caret-up-fill" aria-hidden="true"></i>
                                                                            </td>

                                                                        </tr>

                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                            <table class="collapse in table table-hover  order-column dataTable" id="sample_5" role="grid" aria-describedby="sample_5_info">

                                                                <thead>
                                                                    <tr role="row " class="secondary_bg font-white">
                                                                       <th>ID</th>
                                                                        <th style="">
                                                                            Blog Name
                                                                        </th>
                                                                        <th style=""> Blog Header
                                                                        </th>

                                                                        <th style=""> Launch Date
                                                                        </th>
                                                                        <th style=""> Campaign Message
                                                                        </th>
                                                                        <th style=""> Text Body
                                                                        </th>
                                                                        <th style=""> Pictures
                                                                        </th>


                                                                        <th class=" " tabindex="0" aria-controls="sample_4" rowspan="1" colspan="1" aria-label=" action : activate to sort column ascending" style="width: 59px;"> Actions
                                                                        </th>


                                                                    </tr>
                                                                </thead>

                                                                <tbody>
                                                                    <tr data-toggle="collapse" class="" data-target="#sample_5">

                                                                        <td class="ft-16"><b> 2</b>
                                                                        </td>
                                                                        <td class="ft-16">Zahid</td>
                                                                        <td class="ft-16">Bold</td>
                                                                        <td class="ft-16">12-23-2002
                                                                        </td>
                                                                        <td class="ft-16">
                                                                            Hello Micle</td>
                                                                        <td class="ft-16">175 letters</td>
                                                                        <td class="ft-16"><img src="{{ asset('./assets/img/web.jpg') }}" class="highlight4" height="24" width="24" alt=""></td>
                                                                        <td class="ft-16">
                                                                            <i class="bi bi-caret-up-fill" aria-hidden="true"></i>
                                                                        </td>

                                                                    </tr>

                                                                    <tr data-toggle="collapse" class="" data-target="#sample_5">

                                                                        <td class="ft-16"><b> 1</b>
                                                                        </td>
                                                                        <td class="ft-16">Zafar</td>
                                                                        <td class="ft-16">Bold</td>
                                                                        <td class="ft-16">12-23-2002
                                                                        </td>
                                                                        <td class="ft-16">
                                                                            Hello Micle</td>
                                                                        <td class="ft-16">175 letters</td>
                                                                        <td class="ft-16"><img src="{{ asset('./assets/img/web.jpg') }}" class="highlight4" height="24" width="24" alt=""></td>
                                                                        <td class="ft-16">
                                                                            <i class="bi bi-caret-up-fill" aria-hidden="true"></i>
                                                                        </td>

                                                                    </tr>


                                                                    <tr data-toggle="collapse" class="" data-target="#sample_5">

                                                                        <td class="ft-16"><b> 3</b>
                                                                        </td>
                                                                        <td class="ft-16">Zubair</td>
                                                                        <td class="ft-16">Bold</td>
                                                                        <td class="ft-16">12-23-2002
                                                                        </td>
                                                                        <td class="ft-16">
                                                                            Hello Micle</td>
                                                                        <td class="ft-16">175 letters</td>
                                                                        <td class="ft-16"><img src="{{ asset('./assets/img/web.jpg') }}" class="highlight4" height="24" width="24" alt=""></td>
                                                                        <td class="ft-16">
                                                                            <i class="bi bi-caret-up-fill" aria-hidden="true"></i>
                                                                        </td>

                                                                    </tr>


                                                                </tbody>
                                                            </table>
                                                        </div>


                                                    </div>
                                                </div>

                                            </div>



                                        </div>
                                    </div>

                                </div>
                            </div>


                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- end input -->
</div>

@endsection