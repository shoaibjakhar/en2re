@extends('HR.hrlayouts')
@section('content')

<!-- start body -->
<div class=" page-content-wrapper">
    <!-- start input form -->
    <div class="page-content hero2">
        <div class="portlet light bordered " id="form_wizard_1">
            <div class="portlet-body form">
                <div class="row">

                    <div class="col-md-12 mx-0">
                        <div>
                            <div class="form-group ">

                                <div class="left">
                                    <div class="wrapper center-block">
                                        <div class="left">

                                            <!-- start input form 1 -->
                                            <div class="col-md-10 box-bd">
                                                <div class="portlet-body">
                                                    <h4>FAQ Itom </h4>
                                                    <div class="col-md-11">
                                                        <label class="control-label left ">FAQ item detail</label>
                                                        <input type="text" value="" class="form-control" name="" />
                                                    </div>
                                                    <div class="col-md-1">
                                                        <div class="col-md-1" style="margin-top:50px;">
                                                            <a href=""> <span class="glyphicon glyphicon-trash" style="font-size: 40px;color: black;"></span></a>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                            <!-- end input form 1 -->
                                          
                                            {{--  <!-- start input form 2 -->
                                            <div class="col-md-10 box-bd">
                                                <div class="portlet-body">
                                                    <h4>FAQ Itom 2</h4>
                                                    <div class="col-md-12">
                                                        <label class="control-label left ">FAQ item detail</label>
                                                        <input type="text" value="" class="form-control" name="" />
                                                    </div>
                                                </div>

                                            </div>
                                            <!-- end input form 2 -->
                                            <div class="col-md-2">
                                                <div class="col-md-1" style="margin-top:180px;">
                                                    <a href=""> <span class="glyphicon glyphicon-trash" style="font-size: 40px;color: black;"></span></a>
                                                </div>
                                            </div>
                                            <!-- start input form 3 -->
                                            <div class="col-md-10 box-bd">
                                                <div class="portlet-body">
                                                    <h4>FAQ Itom 3</h4>
                                                    <div class="col-md-12">
                                                        <label class="control-label left ">FAQ item detail</label>
                                                        <input type="text" value="" class="form-control" name="" />
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end input form 3 -->
                                            <div class="col-md-2">
                                                <div class="col-md-1" style="margin-top:180px;">
                                                    <a href="Projects.html"> <span class="glyphicon glyphicon-trash" style="font-size: 40px;color: black;"></span></a>
                                                </div>
                                            </div>

  --}}

                                        </div>
                                    </div>

                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end body -->
<!-- end input form -->
@endsection